the simple macro to automate web browser.
--- It opens chrome and search the data or keywords defined in the excel field.
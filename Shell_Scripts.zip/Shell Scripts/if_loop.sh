#!/usr/bin/bash
if [ -z $1 ]; then
	echo "please enter argument"
else
	echo "your argument is $1"
	exit
fi


#!/usr/bin/bash

echo "File name of current scritp $0"
echo "Agruments for file $1 $2 $3"
echo "No. of agrument supplied $#"
echo "All arguments $*"
echo "Last command Exit status $?"
echo "Process id of current shell $$"
echo "Process no. of last bckground cmd $!"


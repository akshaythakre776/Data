#!/usr/bin/bash
data=myhome_directory_$(date +%Y%m%d).tar.gz
tar -czf $data "/c/User/athakre/Desktop/Shell Script/"

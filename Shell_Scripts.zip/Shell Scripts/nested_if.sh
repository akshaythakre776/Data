#!/usr/bin/bash
echo Enter UserName
read uname

if [ "$uname" == "akshay" ]; then

	echo Enter Password
	read -s Password

if [ "$Password" == "akshay123" ]; then
	echo "Welcome $uname"
else
	echo "Wrong Password"
fi
else
	echo "Wrong UserName"
fi


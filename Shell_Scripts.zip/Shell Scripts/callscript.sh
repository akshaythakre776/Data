#!/usr/bin/bash

./if_loop.sh $1

#!/usr/bin/bash
name[0]="a"
name[1]="b"
name[2]="c"

echo ${name[0]}

#!/usr/bin/bash

echo Enter first No.
read a
echo Enter second No.
read b
if [ $a -ge 0 ] && [ $b -ge 0 ]; then

	echo `expr $a + $b`
	echo `expr $a - $b`
	echo `expr $a \* $b`
	echo `expr $a / $b`
	echo `expr $a % $b`
else
	echo Enter valid numbers
fi
